//*******************************************************************
// *  Patch Clamp
// *  2002 Tobias Huth  
// *  CAU KIEL 
//*******************************************************************/
#include "gtkfunc.h"
#include "datarray.h"

class TRausch
{
	
 private:
//schon mal initialisiert? 
 bool initialized;
 bool fitinaction;

//extralaenge um eine zirkul�re noiseserie zu erzeugen, damit der Filter am Anfang der serie schon "eingeschwungen" ist
 unsigned long int extralength; 		//Tobias 2022 long int
 // char storefilename[255];				//Tobias 2022
 


 void delete_array();
 void initial_array();
 void create_distribution();
 void load_noisefile(char name[255]);
 void save_noisefile(char name[255]);
 void create_lowpass(unsigned int SamplingFrequency, 
 		     						 unsigned int FilterFrequency);
 
 
 public:
//array f�r die Rauschreihe
 double *tnoiseseries;
 double *tnoiseseries_padding; //Tobias 2021
//L�nge der Rauschreihe 
 unsigned long int length_noiseseries; 					//Tobias 2022 long int
  //unsigned long int length_noiseseries_load; 		//Tobias 2022 long int
 

 TRausch();
 ~TRausch();
 

 
 void makenoise(unsigned long int length,					//Tobias 2022 long int
  		unsigned int sampling_frequency,
  		unsigned int filter_frequency, 
  		bool resample,
  		char filename[255]);

};









