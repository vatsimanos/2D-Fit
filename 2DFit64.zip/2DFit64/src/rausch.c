/*******************************************************************
 *  Patch Clamp
 *  2003 Tobias Huth  
 *  CAU KIEL 
/*******************************************************************/


#include "rausch.h"
#include "bessel.h"		//Tobias 2021 included for 4 pole Bessel LP filter

TRausch::TRausch()
{
initialized = false;
fitinaction = false;
/*
erzeugt mit matlab:
[b,a] = besself(4,31415.927);
[y,x,t] = step(b,a)  
y = rot90(y)
save bessel_f.mat y
*/
length_noiseseries = 32000;
}

TRausch::~TRausch()
{
if (initialized)
 delete_array();	
}


//*******************************************************************
void TRausch::delete_array()
{
delete[] tnoiseseries;	
}


//*******************************************************************
void TRausch::initial_array()
{
 if (tnoiseseries == 0)				//2021 Tobias added this line for fixing memory leak		
			tnoiseseries = new double[length_noiseseries];
}


//*******************************************************************
void TRausch::create_distribution()
{
 int64_t i;
 tnoiseseries_padding = new double[length_noiseseries+2*extralength+6]; //create temporary noise series that will be filtered and transfered to noiseries
 for(i=0; i < (length_noiseseries+2*extralength); i++)
  { 
   tnoiseseries_padding[i] = Daten.snd_01(Daten.random_engine);
  }   
   
 for(i=0; i < length_noiseseries; i++) 
 		tnoiseseries[i] = tnoiseseries_padding[i+extralength];
}


//*******************************************************************
void TRausch::create_lowpass(unsigned int SamplingFrequency, unsigned int FilterFrequency)
{		
 int64_t i;
 double mean, sigma;
 double cutoff;
 
//initialize bessel filter 
cutoff = 2.0 *(double) FilterFrequency/(double) SamplingFrequency;			//calculate cutoff
bessel *lpfilter = initialize_filter(4, cutoff, length_noiseseries, extralength-1);		//order of Bessel filter, cutoff frequency, length?

//apply LP Bessel filter to white noise
filter_signal(tnoiseseries, tnoiseseries_padding, lpfilter, length_noiseseries);		//data, padding, filter, length	
 
for(i=0; i < length_noiseseries; i++)
   tnoiseseries[i] = tnoiseseries_padding[i+ extralength];
  
delete[] tnoiseseries_padding; //get rid off this memory hog
free_filter(lpfilter);

//Einstellung der neuen Standardabweichung
mean = 0;
sigma = 0;
for(i=0; i < length_noiseseries; i++)
  mean += tnoiseseries[i];
mean = mean / length_noiseseries;

for(i=0; i < length_noiseseries; i++)
  sigma += (tnoiseseries[i]- mean) * (tnoiseseries[i]-mean);
sigma = sqrt (sigma / (length_noiseseries-1));  


for(i=0; i < length_noiseseries; i++)
   tnoiseseries[i] = tnoiseseries[i]  / sigma;	

initialized = true;
}



//*******************************************************************
void TRausch::load_noisefile(char* Filename)
{
 unsigned int i;	
 unsigned short  dummy;
 double mean, sigma;
   std::cout<<"##############################loading noise"<<std::endl;	
   	
 std::ifstream in(Filename, std::ifstream::binary);	
 if (!in)
  {
   std::cout<<"Cant load noisefile:"<<Filename<<" ,loading aborted!!!!!!!!!!!!!"<<std::endl;
  }
 else
  {
   in.read((char *)&length_noiseseries, 8);  
   in.seekg(0, std::ios::end);                                // Filelaenge in bytes
//Tobias Anz_Samples = MIN(Anz_Samples, (in.tellg() - 4) / 2); // ermitteln, pruefen ob zu klein?
   length_noiseseries = ((int)in.tellg() - 8) / 2; //Tobias
   //length_noiseseries_load = length_noiseseries;		//Tobias 2022
   
   in.seekg(8, std::ios::beg);                                  // streampos auf ersten wert

  tnoiseseries = new double[length_noiseseries];          // pointer auf neue daten

  for (i=0; i  <length_noiseseries; i++)
    {
     in.read((char *)&dummy,2);           // Werte sind 2byte gross 
     dummy &= 0x0fff;		  // Marker l�schen
     tnoiseseries[i] = (double) dummy + Daten.uni_11(Daten.random_engine);  //Bitrauschenn durch antialiasing vermeiden: VNI = random(-1..+1) 	
    }    
//Einstellung der neuen Standardabweichung, normieren auf 1
  mean = 0;
  sigma = 0;
  for(i=0; i < length_noiseseries; i++)
    mean += tnoiseseries[i];
  mean = mean / length_noiseseries;

  for(i=0; i < length_noiseseries; i++)
    sigma += (tnoiseseries[i]- mean) * (tnoiseseries[i]-mean);
  sigma = sqrt (sigma / (length_noiseseries-1));  
  std::cout<<"mean: "<<mean<<" sigma: "<<sigma<<std::endl; 
  std::cout<<"loaded data:"<<length_noiseseries<<" from:"<<Filename<<" with mean:"<<mean<<" and sigma:"<<sigma<<std::endl;	
 
  for(i=0; i < length_noiseseries; i++)
   {
    tnoiseseries[i] = (tnoiseseries[i] - mean)  / sigma;  
   } 
  initialized = true;
  }	

}
//*******************************************************************
void TRausch::save_noisefile(char Filename[255])
{
int	i;
int  dummy;
	
std::ofstream out(Filename, std::ios::out|std::ios::binary);

out.write((char *)&length_noiseseries,4);

for(i=0; i < length_noiseseries; i++)
  {
   dummy = int(tnoiseseries[i]);
   out.write((char *) &dummy,4);
  } 

out.close();	
}	

//*******************************************************************


void TRausch::makenoise(unsigned long int length,						//TObias 2022
  			unsigned int sampling_frequency,
  			unsigned int filter_frequency, 
  			bool resample,
  			char* filename)
{	

extralength = (unsigned long int)sampling_frequency / filter_frequency * 4;
length_noiseseries = length;
//if (strlen(filename) > 0)				//Tobias 2022
//length_noiseseries = length_noiseseries_load;	


if (strcmp(filename,"none") != 0) 
   {			
    if (Daten.Geneticfitparameter.file_noise_series_loaded == false) //Tobias 2022
      {
       load_noisefile(filename);
       Daten.Geneticfitparameter.file_noise_series_loaded = true;
      } 
   }     
else
	 {
	 	if (resample)
	 		{
	 		 initial_array();
       create_distribution();
       create_lowpass(sampling_frequency, filter_frequency);
       resample = false;          	
      }
    else
    	{
    	 if (!fitinaction)
    	 {
    	 	initial_array();
        create_distribution();
        create_lowpass(sampling_frequency, filter_frequency);
        fitinaction = true;
    	 }		
      }	    
	 }	


}






