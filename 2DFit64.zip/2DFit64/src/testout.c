#include <iostream>
#include "declare.h"
#include "matu.h"
#include "fit.h"
#include "declare.h"
/*
void
printTRate_matrix(TRate_matrix matrix, char* text = NULL)
{
  //cout << text << endl;
  for (int i=0;i < n_states_max;i++)
  {
	//cout << i << ": ";
    for (int j=0;j < n_states_max;j++)
	{ 
	  //cout << matrix.r[i][j] << " ";
	}
    //cout << "      " << matrix.open[i] << endl; 
  }
}

void
printVecDarray(VecD* vec, int x, char* text = NULL)
{
  //cout << text << endl;
  for (int i=0;i<x;i++)
  {
	//cout << i << ": ";
    for (int j=1;j<matu_u_dim+1;j++)
	{ 
	  //cout << vec[i][j] << " ";
	}
    //cout << endl; 
  }
}


void 
printTUntermatrix_vector(std::vector<TUntermatrix> &vec, char* text = NULL)
{
  //cout << text << endl;
  std::vector<TUntermatrix>::iterator iter;

  for(iter=vec.begin();iter != vec.end();iter++)
  {
	//cout << (*iter).dimension << " " 
	//	 << (*iter).start_index << " "
	//	 << (*iter).stop_index << endl;
  }
}

void
printTMultiSteady(TMultiSteady &multi, char* text = NULL)
{
  //cout << text << endl;

  for (int i=1; i<=max_dim_big_matrix;i++)
  {
    //cout << i << ": " << multi[i] << "       ";
  }
  //cout << endl;
}


void
printTMultiSteadyP(double* multi, char* text = NULL)
{
  //cout << text << endl;


  for (int i=1; i<=max_dim_big_matrix;i++)
  {
//	double wert = *(multi+i);
    //cout << i << ": " << wert << "       ";
  }
  //cout << endl;
}
*/
