

for i in {1..1}; do
mpiexec -n 2 ~/KielPatch_2/2DFit64  
done
																																																																																# test mpi max= 72

